import 'dart:convert';
import 'dart:ui' as ui;
import 'dart:io';
import 'package:archive/archive.dart';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:html/parser.dart' as html_parser;
import 'package:http/http.dart' as http;
import 'package:qr_flutter/qr_flutter.dart';
import 'package:shared_preferences/shared_preferences.dart';

const bg = Color(0xFF101014);
const panel = Color(0xFF1B1A20);
const gold = Color(0xFFD7B77A);
const muted = Color(0xFFAAA3A0);


class ReaderPalette {
  const ReaderPalette({required this.name, required this.background, required this.text,
    required this.accent, required this.panel});
  final String name;
  final Color background, text, accent, panel;
  ReaderPalette copyWith({String? name, Color? background, Color? text, Color? accent, Color? panel}) =>
    ReaderPalette(name: name ?? this.name, background: background ?? this.background,
      text: text ?? this.text, accent: accent ?? this.accent, panel: panel ?? this.panel);

  static const presets = <ReaderPalette>[
    ReaderPalette(name: '奶油纸', background: Color(0xFFF2EADB), text: Color(0xFF3B3329), accent: Color(0xFF9B7950), panel: Color(0xFFE6DDCE)),
    ReaderPalette(name: '羊皮古卷', background: Color(0xFFE7D6B8), text: Color(0xFF493622), accent: Color(0xFF95643C), panel: Color(0xFFD8C4A3)),
    ReaderPalette(name: '雾蓝诗笺', background: Color(0xFFE4ECF0), text: Color(0xFF293B49), accent: Color(0xFF587F9A), panel: Color(0xFFD2E0E7)),
    ReaderPalette(name: '樱花笺', background: Color(0xFFF3E4E5), text: Color(0xFF50363D), accent: Color(0xFFB66F83), panel: Color(0xFFEBD3D8)),
    ReaderPalette(name: '薄荷森语', background: Color(0xFFE4EDE3), text: Color(0xFF304333), accent: Color(0xFF668B68), panel: Color(0xFFD2E2D1)),
    ReaderPalette(name: '薰衣草', background: Color(0xFFECE7F3), text: Color(0xFF40364F), accent: Color(0xFF8872AC), panel: Color(0xFFDDD5EA)),
    ReaderPalette(name: '午夜墨黑', background: Color(0xFF09090B), text: Color(0xFFE9E5DC), accent: Color(0xFFD7B77A), panel: Color(0xFF28262D)),
    ReaderPalette(name: '深海蓝', background: Color(0xFF101C29), text: Color(0xFFDCE8F2), accent: Color(0xFF78A9D2), panel: Color(0xFF1C2B3A)),
    ReaderPalette(name: '松针夜绿', background: Color(0xFF14201B), text: Color(0xFFE0E9DF), accent: Color(0xFF91B58D), panel: Color(0xFF24342B)),
  ];
}



class BookSource {
  BookSource({required this.name, required this.endpoint, this.queryParam = 'q',
    this.kind = '私人书源', this.enabled = true, this.lastLatencyMs, this.status = '未检测',
    this.subscriptionUrl});
  String name;
  String endpoint;
  String? subscriptionUrl;
  String queryParam;
  String kind;
  bool enabled;
  int? lastLatencyMs;
  String status;

  Map<String, dynamic> toJson() => {
    'name': name, 'endpoint': endpoint, 'queryParam': queryParam,
    'kind': kind, 'enabled': enabled, 'lastLatencyMs': lastLatencyMs, 'status': status,
    'subscriptionUrl': subscriptionUrl,
  };
  factory BookSource.fromJson(Map<String, dynamic> j) => BookSource(
    name: (j['name'] ?? '').toString(),
    endpoint: (j['endpoint'] ?? j['baseUrl'] ?? '').toString(),
    queryParam: (j['queryParam'] ?? 'q').toString(),
    kind: (j['kind'] ?? '私人书源').toString(),
    enabled: j['enabled'] != false,
    lastLatencyMs: j['lastLatencyMs'] is num ? (j['lastLatencyMs'] as num).toInt() : null,
    status: (j['status'] ?? '未检测').toString(),
    subscriptionUrl: j['subscriptionUrl']?.toString(),
  );
}

class SourceSearchResult {
  const SourceSearchResult({required this.title, this.author = '', this.description = '',
    this.url = '', required this.sourceName, required this.latencyMs});
  final String title, author, description, url, sourceName;
  final int latencyMs;
}

class AppLook {
  const AppLook({required this.name, required this.background, required this.surface,
    required this.accent, required this.text, required this.muted,
    required this.nav, required this.heroStart, required this.heroEnd});
  final String name;
  final Color background, surface, accent, text, muted, nav, heroStart, heroEnd;

  static const presets = <AppLook>[
    AppLook(name: '暗夜鎏金', background: Color(0xFF101014), surface: Color(0xFF1B1A20),
      accent: Color(0xFFD7B77A), text: Color(0xFFF1E8D9), muted: Color(0xFFAAA7B1),
      nav: Color(0xE824232A), heroStart: Color(0xFF493725), heroEnd: Color(0xFF211D22)),
    AppLook(name: '奶油书房', background: Color(0xFFF4EFE6), surface: Color(0xFFEAE1D3),
      accent: Color(0xFF9B7950), text: Color(0xFF382F26), muted: Color(0xFF827668),
      nav: Color(0xEDEAE1D5), heroStart: Color(0xFFE8D7BC), heroEnd: Color(0xFFD5C1A2)),
    AppLook(name: '雾海蓝调', background: Color(0xFF101B27), surface: Color(0xFF1B2A39),
      accent: Color(0xFF86B8DA), text: Color(0xFFE5EEF5), muted: Color(0xFFA5B5C3),
      nav: Color(0xE8213040), heroStart: Color(0xFF294B64), heroEnd: Color(0xFF172B3C)),
    AppLook(name: '樱花物语', background: Color(0xFF21191E), surface: Color(0xFF30232B),
      accent: Color(0xFFE5A0B2), text: Color(0xFFF8EAF0), muted: Color(0xFFC4AAB4),
      nav: Color(0xE832242D), heroStart: Color(0xFF684151), heroEnd: Color(0xFF2E2029)),
    AppLook(name: '森林秘境', background: Color(0xFF121D18), surface: Color(0xFF1E2B23),
      accent: Color(0xFF9BC49A), text: Color(0xFFE7F0E5), muted: Color(0xFFAAB9A8),
      nav: Color(0xE824332A), heroStart: Color(0xFF34513D), heroEnd: Color(0xFF19281F)),
    AppLook(name: '薰衣草夜', background: Color(0xFF191722), surface: Color(0xFF272333),
      accent: Color(0xFFB9A5E5), text: Color(0xFFF0ECFA), muted: Color(0xFFB7AEC8),
      nav: Color(0xE82D293B), heroStart: Color(0xFF51466C), heroEnd: Color(0xFF292436)),
  ];
}

void main() => runApp(const XiaoShuYuanApp());

class Book {
  Book({required this.title, required this.author, required this.content,
    this.source = '本地导入', this.coverColor = const Color(0xFF4B3A2B)});
  final String title, author, content, source;
  final Color coverColor;
  int progress = 0;
  String description = '';
}

List<String> splitBookChapters(String content) {
  final text = content.trim();
  if (text.isEmpty) return const [];
  final lines = text.split(RegExp(r'\\r?\\n'));
  final heading = RegExp(r'^\\s*(第[零一二三四五六七八九十百千万0-9]+[章节回卷部篇].*|序章|楔子|后记|番外.*)$');
  final chapters = <String>[];
  var current = StringBuffer();
  for (final line in lines) {
    if (heading.hasMatch(line.trim()) && current.toString().trim().isNotEmpty) {
      chapters.add(current.toString().trim());
      current = StringBuffer();
    }
    current.writeln(line);
  }
  if (current.toString().trim().isNotEmpty) chapters.add(current.toString().trim());
  return chapters.isEmpty ? [text] : chapters;
}

class XiaoShuYuanApp extends StatefulWidget {
  const XiaoShuYuanApp({super.key});
  @override
  State<XiaoShuYuanApp> createState() => _XiaoShuYuanAppState();
}

class _XiaoShuYuanAppState extends State<XiaoShuYuanApp> {
  int tab = 0;
  final List<Book> books = [
    Book(title: '山海长夜', author: '小书苑示例作品',
      source: '示例内容', content: '第一章：长夜初醒\n\n山风穿过古老的松林，远处的群山隐没在薄雾之中。少年站在石阶尽头，望着天边渐渐亮起的星光。\n\n这是一个关于山海、旅途与成长的原创演示故事。\n\n第二章：山门之外\n\n清晨的钟声从山门深处传来。少年收好行囊，踏上了未知的旅程。'),
    Book(title: '月下书信', author: '小书苑示例作品',
      source: '示例内容', content: '第一章：一封信\n\n窗外落着细雨，桌上的信笺写着一个熟悉的名字。故事，就从这个安静的夜晚开始。'),
  ];
  String query = '';
  bool darkReader = false;
  double fontSize = 19;
  ReaderPalette readerPalette = ReaderPalette.presets.first;
  AppLook appLook = AppLook.presets.first;
  List<int> favoriteLookIds = [];
  final List<BookSource> bookSources = [];
  List<String> sourceSubscriptions = [];
  List<SourceSearchResult> sourceResults = [];
  bool sourceSearching = false;
  String sourceSearchMessage = '';

  @override
  void initState() {
    super.initState();
    _loadSettings();
  }

  Future<void> _loadSettings() async {
    final p = await SharedPreferences.getInstance();
    setState(() {
      fontSize = p.getDouble('fontSize') ?? 19;
      darkReader = p.getBool('darkReader') ?? false;
      final lookIndex = p.getInt('appLookIndex') ?? 0;
      appLook = AppLook.presets[lookIndex.clamp(0, AppLook.presets.length - 1)];
      favoriteLookIds = (p.getStringList('favoriteLookIds') ?? []).map((e) => int.tryParse(e) ?? 0).toList();
      sourceSubscriptions = p.getStringList('sourceSubscriptions') ?? [];
      bookSources
        ..clear()
        ..addAll((p.getStringList('bookSources') ?? []).map((raw) {
          try { return BookSource.fromJson(jsonDecode(raw) as Map<String, dynamic>); }
          catch (_) { return null; }
        }).whereType<BookSource>());
      final bgValue = p.getInt('paletteBg');
      final textValue = p.getInt('paletteText');
      final accentValue = p.getInt('paletteAccent');
      final panelValue = p.getInt('palettePanel');
      if (bgValue != null && textValue != null && accentValue != null && panelValue != null) {
        readerPalette = ReaderPalette(name: p.getString('paletteName') ?? '我的搭配',
          background: Color(bgValue), text: Color(textValue),
          accent: Color(accentValue), panel: Color(panelValue));
      }
    });
    final presetSources = <BookSource>[
      BookSource(
        name: 'Project Gutenberg · 综合书库',
        endpoint: 'https://gutendex.com/books/',
        queryParam: 'search',
        kind: '公共领域书库',
      ),
      BookSource(
        name: '公版题材 · 冒险',
        endpoint: Uri.https('gutendex.com', '/books/', {'topic': 'adventure'}).toString(),
        queryParam: 'search',
        kind: '公版题材书库',
      ),
      BookSource(
        name: '公版题材 · 悬疑侦探',
        endpoint: Uri.https('gutendex.com', '/books/', {'topic': 'mystery'}).toString(),
        queryParam: 'search',
        kind: '公版题材书库',
      ),
      BookSource(
        name: '公版题材 · 科幻',
        endpoint: Uri.https('gutendex.com', '/books/', {'topic': 'science fiction'}).toString(),
        queryParam: 'search',
        kind: '公版题材书库',
      ),
      BookSource(
        name: '公版题材 · 奇幻',
        endpoint: Uri.https('gutendex.com', '/books/', {'topic': 'fantasy'}).toString(),
        queryParam: 'search',
        kind: '公版题材书库',
      ),
      BookSource(
        name: '公版题材 · 历史',
        endpoint: Uri.https('gutendex.com', '/books/', {'topic': 'history'}).toString(),
        queryParam: 'search',
        kind: '公版题材书库',
      ),
      BookSource(
        name: '公版题材 · 言情/爱情经典',
        endpoint: Uri.https('gutendex.com', '/books/', {'topic': 'romance'}).toString(),
        queryParam: 'search',
        kind: '公版题材书库',
      ),
      BookSource(
        name: '公版题材 · LGBTQ+情感经典',
        endpoint: Uri.https('gutendex.com', '/books/', {'topic': 'gay'}).toString(),
        queryParam: 'search',
        kind: '公版题材书库',
      ),
      BookSource(
        name: 'Open Library · 言情/爱情',
        endpoint: 'https://openlibrary.org/search.json?q=subject:romance',
        queryParam: 'title',
        kind: '正版书目目录',
      ),
      BookSource(
        name: 'Open Library · LGBTQ+情感文学',
        endpoint: 'https://openlibrary.org/search.json?q=(subject:lgbtq%20OR%20subject:%22gay%20men%22%20OR%20subject:lesbians)',
        queryParam: 'title',
        kind: '正版书目目录',
      ),
    ];
    var addedPreset = false;
    for (final preset in presetSources) {
      if (!bookSources.any((source) => source.endpoint == preset.endpoint)) {
        bookSources.add(preset);
        addedPreset = true;
      }
    }
    if (addedPreset) {
      setState(() {});
      await _saveSettings();
    }
  }

  Future<void> _saveSettings() async {
    final p = await SharedPreferences.getInstance();
    await p.setDouble('fontSize', fontSize);
    await p.setBool('darkReader', darkReader);
    await p.setInt('appLookIndex', AppLook.presets.indexOf(appLook).clamp(0, AppLook.presets.length - 1));
    await p.setStringList('favoriteLookIds', favoriteLookIds.map((e) => e.toString()).toList());
    await p.setStringList('bookSources', bookSources.map((s) => jsonEncode(s.toJson())).toList());
    await p.setStringList('sourceSubscriptions', sourceSubscriptions);
    await p.setString('paletteName', readerPalette.name);
    await p.setInt('paletteBg', readerPalette.background.value);
    await p.setInt('paletteText', readerPalette.text.value);
    await p.setInt('paletteAccent', readerPalette.accent.value);
    await p.setInt('palettePanel', readerPalette.panel.value);
  }

  void _applyPalette(ReaderPalette palette) {
    setState(() {
      readerPalette = palette;
      darkReader = palette.background.computeLuminance() < .12;
    });
    _saveSettings();
  }


  bool _isSafeSourceUri(Uri uri) {
    if (uri.scheme != 'https' || uri.host.isEmpty || uri.userInfo.isNotEmpty) return false;
    final host = uri.host.toLowerCase();
    if (host == 'localhost' || host.endsWith('.local') || host.endsWith('.internal')) return false;
    final ip = InternetAddress.tryParse(host);
    if (ip != null) {
      if (ip.type == InternetAddressType.IPv4) {
        final parts = host.split('.').map(int.parse).toList();
        if (parts[0] == 10 || parts[0] == 127 || parts[0] == 0 ||
            (parts[0] == 169 && parts[1] == 254) ||
            (parts[0] == 172 && parts[1] >= 16 && parts[1] <= 31) ||
            (parts[0] == 192 && parts[1] == 168) ||
            parts[0] >= 224) return false;
      } else {
        final normalized = host.toLowerCase();
        if (normalized == '::1' || normalized.startsWith('fc') ||
            normalized.startsWith('fd') || normalized.startsWith('fe80')) return false;
      }
    }
    return true;
  }

  Future<void> _addSourceByUrl(String name, String endpoint, String queryParam, String kind) async {
    final uri = Uri.tryParse(endpoint.trim());
    if (uri == null || !_isSafeSourceUri(uri)) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('地址无效：仅支持安全的 HTTPS 公网接口地址')),
      );
      return;
    }
    if (bookSources.any((s) => s.endpoint == uri.toString())) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('这个书源已经添加过了')),
      );
      return;
    }
    setState(() => bookSources.add(BookSource(
      name: name.trim().isEmpty ? uri.host : name.trim(),
      endpoint: uri.toString(), queryParam: queryParam.trim().isEmpty ? 'q' : queryParam.trim(),
      kind: kind,
    )));
    await _saveSettings();
    if (mounted) ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('书源已添加，请先进行连接测试')),
    );
  }

  Future<void> _addPublicDomainSource() async {
    final presets = <BookSource>[
      BookSource(name: 'Project Gutenberg · 综合书库',
        endpoint: 'https://gutendex.com/books/', queryParam: 'search', kind: '公共领域书库'),
      BookSource(name: '公版题材 · 冒险',
        endpoint: Uri.https('gutendex.com', '/books/', {'topic': 'adventure'}).toString(),
        queryParam: 'search', kind: '公版题材书库'),
      BookSource(name: '公版题材 · 悬疑侦探',
        endpoint: Uri.https('gutendex.com', '/books/', {'topic': 'mystery'}).toString(),
        queryParam: 'search', kind: '公版题材书库'),
      BookSource(name: '公版题材 · 科幻',
        endpoint: Uri.https('gutendex.com', '/books/', {'topic': 'science fiction'}).toString(),
        queryParam: 'search', kind: '公版题材书库'),
      BookSource(name: '公版题材 · 奇幻',
        endpoint: Uri.https('gutendex.com', '/books/', {'topic': 'fantasy'}).toString(),
        queryParam: 'search', kind: '公版题材书库'),
      BookSource(name: '公版题材 · 历史',
        endpoint: Uri.https('gutendex.com', '/books/', {'topic': 'history'}).toString(),
        queryParam: 'search', kind: '公版题材书库'),
      BookSource(name: '公版题材 · 言情/爱情经典',
        endpoint: Uri.https('gutendex.com', '/books/', {'topic': 'romance'}).toString(),
        queryParam: 'search', kind: '公版题材书库'),
      BookSource(name: '公版题材 · LGBTQ+情感经典',
        endpoint: Uri.https('gutendex.com', '/books/', {'topic': 'gay'}).toString(),
        queryParam: 'search', kind: '公版题材书库'),
      BookSource(
        name: 'Open Library · 言情/爱情',
        endpoint: 'https://openlibrary.org/search.json?q=subject:romance',
        queryParam: 'title',
        kind: '正版书目目录',
      ),
      BookSource(
        name: 'Open Library · LGBTQ+情感文学',
        endpoint: 'https://openlibrary.org/search.json?q=(subject:lgbtq%20OR%20subject:%22gay%20men%22%20OR%20subject:lesbians)',
        queryParam: 'title',
        kind: '正版书目目录',
      ),
    ];
    var added = 0;
    for (final source in presets) {
      if (!bookSources.any((s) => s.endpoint == source.endpoint)) {
        bookSources.add(source);
        added++;
      }
    }
    if (added > 0) {
      setState(() {});
      await _saveSettings();
    }
    if (mounted) ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(added == 0 ? '公版题材书库已经全部添加过了' : '已添加 $added 个公版题材书库')),
    );
  }


  Future<void> _exportSourcePack(String payload) async {
    try {
      final path = await FilePicker.platform.saveFile(
        dialogTitle: '导出小书苑书源分享包',
        fileName: 'xiaoshuyuan_sources.json',
        type: FileType.custom,
        allowedExtensions: ['json'],
        bytes: utf8.encode(const JsonEncoder.withIndent('  ').convert(jsonDecode(payload))),
      );
      if (!mounted) return;
      if (path != null) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('分享配置文件已导出，可上传到你信任的 HTTPS 文件托管服务')),
        );
      }
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('导出失败：$e')),
      );
    }
  }

  Future<void> _shareSourceConfig() async {
    if (bookSources.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('当前还没有书源可以分享')),
      );
      return;
    }
    final payload = jsonEncode({
      'format': 'xiaoshuyuan-source-pack',
      'version': 1,
      'subscriptions': sourceSubscriptions,
      'sources': bookSources.map((source) => {
        'name': source.name,
        'endpoint': source.endpoint,
        'queryParam': source.queryParam,
        'kind': source.kind,
        'enabled': source.enabled,
      }).toList(),
    });
    await Clipboard.setData(ClipboardData(text: const JsonEncoder.withIndent('  ').convert(jsonDecode(payload))));
    if (!mounted) return;
    await showDialog<void>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('分享书源配置'),
        content: SingleChildScrollView(child: Column(mainAxisSize: MainAxisSize.min, children: [
          const Text('可让朋友使用二维码扫描器识别并保存配置内容，再通过小书苑的 JSON 文件导入功能导入。'),
          const SizedBox(height: 12),
          Container(
            color: Colors.white,
            padding: const EdgeInsets.all(12),
            child: QrImageView(data: payload, version: QrVersions.auto, size: 230),
          ),
          const SizedBox(height: 8),
          const Text('配置内容也已复制到剪贴板。二维码容量有限，书源较多时请使用复制的 JSON 文件内容。'),
        ])),
        actions: [
          TextButton(
            onPressed: () => _exportSourcePack(payload),
            child: const Text('导出 JSON'),
          ),
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('完成')),
        ],
      ),
    );
  }

  Future<void> _subscribeSourceLink() async {
    final controller = TextEditingController();
    final link = await showDialog<String>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('从链接订阅书源'),
        content: TextField(
          controller: controller,
          keyboardType: TextInputType.url,
          decoration: const InputDecoration(
            hintText: 'https://example.com/sources.json',
            helperText: '仅支持 HTTPS 的 JSON/TXT 书源配置链接',
          ),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('取消')),
          FilledButton(onPressed: () => Navigator.pop(ctx, controller.text.trim()),
            child: const Text('获取配置')),
        ],
      ),
    );
    if (link == null || link.isEmpty) return;
    final uri = Uri.tryParse(link);
    if (uri == null || !_isSafeSourceUri(uri) || uri.host.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('链接无效：必须是安全的 HTTPS 公网地址')),
      );
      return;
    }
    try {
      final response = await http.get(uri, headers: {'Accept': 'application/json, text/plain'})
        .timeout(const Duration(seconds: 15));
      if (response.statusCode < 200 || response.statusCode >= 300) {
        throw Exception('HTTP ${response.statusCode}');
      }
      if (response.bodyBytes.length > 1024 * 1024) {
        throw Exception('配置文件超过 1 MB，已拒绝导入');
      }
      final raw = utf8.decode(response.bodyBytes, allowMalformed: true).trim();
      final candidates = <BookSource>[];
      var skipped = 0;
      dynamic decoded;
      try { decoded = jsonDecode(raw); } catch (_) { decoded = null; }
      final entries = <dynamic>[];
      if (decoded is List) {
        entries.addAll(decoded);
      } else if (decoded is Map) {
        final map = Map<String, dynamic>.from(decoded);
        final nested = map['sources'] ?? map['data'] ?? map['bookSources'];
        if (nested is List) { entries.addAll(nested); } else { entries.add(map); }
      } else {
        for (final line in raw.split(RegExp(r'\r?\n'))) {
          final value = line.trim();
          if (value.isEmpty || value.startsWith('#')) continue;
          try {
            final item = jsonDecode(value);
            if (item is Map) { entries.add(item); continue; }
          } catch (_) {}
          final parts = value.split('|').map((e) => e.trim()).toList();
          if (parts.length >= 2) {
            entries.add({'name': parts[0], 'endpoint': parts[1],
              'queryParam': parts.length > 2 ? parts[2] : 'q'});
          } else { skipped++; }
        }
      }
      for (final entry in entries) {
        if (entry is! Map) { skipped++; continue; }
        final map = Map<String, dynamic>.from(entry);
        final name = (map['name'] ?? map['bookSourceName'] ?? map['title'] ?? '').toString().trim();
        final endpoint = (map['endpoint'] ?? map['searchUrl'] ??
          map['searchEndpoint'] ?? map['api'] ?? '').toString().trim();
        final endpointUri = Uri.tryParse(endpoint);
        if (name.isEmpty || endpointUri == null || !_isSafeSourceUri(endpointUri)) {
          skipped++; continue;
        }
        if (bookSources.any((source) => source.endpoint == endpointUri.toString()) ||
            candidates.any((source) => source.endpoint == endpointUri.toString())) continue;
        candidates.add(BookSource(
          name: name, endpoint: endpointUri.toString(),
          queryParam: (map['queryParam'] ?? map['searchParam'] ?? 'q').toString(),
          kind: map['kind'] == '正版授权书源' ? '正版授权书源' : '私人书源',
          enabled: map['enabled'] != false,
          subscriptionUrl: uri.toString(),
        ));
      }
      if (!mounted) return;
      if (candidates.isEmpty) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('没有可导入的书源，跳过 $skipped 条不兼容配置')),
        );
        return;
      }
      final accepted = await showDialog<bool>(
        context: context,
        builder: (ctx) => AlertDialog(
          title: const Text('订阅内容预览'),
          content: SizedBox(
            width: double.maxFinite,
            child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('发现 ${candidates.length} 个新书源，跳过 $skipped 条不兼容配置。'),
              const SizedBox(height: 8),
              SizedBox(height: 240, child: ListView(
                shrinkWrap: true,
                children: candidates.take(10).map((source) => ListTile(
                  dense: true, contentPadding: EdgeInsets.zero,
                  title: Text(source.name),
                  subtitle: Text(source.endpoint, maxLines: 2, overflow: TextOverflow.ellipsis),
                )).toList(),
              )),
              const Text('导入后请逐个测试连接。只添加你信任的配置发布者。'),
            ]),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('取消')),
            FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('确认导入')),
          ],
        ),
      );
      if (accepted == true && mounted) {
        setState(() {
          bookSources.addAll(candidates);
          if (!sourceSubscriptions.contains(uri.toString())) {
            sourceSubscriptions.add(uri.toString());
          }
        });
        await _saveSettings();
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('已导入 ${candidates.length} 个书源，并保存订阅地址')),
        );
      }
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('获取订阅配置失败：$e')),
      );
    } finally {
      controller.dispose();
    }
  }

  Future<void> _refreshSourceSubscriptions() async {
    if (sourceSubscriptions.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('还没有订阅配置链接，请先使用“链接订阅”添加')),
      );
      return;
    }
    var added = 0;
    var updated = 0;
    var failed = 0;
    for (final link in List<String>.from(sourceSubscriptions)) {
      try {
        final uri = Uri.tryParse(link);
        if (uri == null || !_isSafeSourceUri(uri)) { failed++; continue; }
        final response = await http.get(uri, headers: {'Accept': 'application/json, text/plain'})
          .timeout(const Duration(seconds: 15));
        if (response.statusCode < 200 || response.statusCode >= 300 ||
            response.bodyBytes.length > 1024 * 1024) { failed++; continue; }
        final raw = utf8.decode(response.bodyBytes, allowMalformed: true).trim();
        dynamic decoded;
        try { decoded = jsonDecode(raw); } catch (_) { decoded = null; }
        final entries = <dynamic>[];
        if (decoded is List) {
          entries.addAll(decoded);
        } else if (decoded is Map) {
          final map = Map<String, dynamic>.from(decoded);
          final nested = map['sources'] ?? map['data'] ?? map['bookSources'];
          if (nested is List) { entries.addAll(nested); } else { entries.add(map); }
        } else {
          for (final line in raw.split(RegExp(r'\r?\n'))) {
            final value = line.trim();
            if (value.isEmpty || value.startsWith('#')) continue;
            try {
              final item = jsonDecode(value);
              if (item is Map) { entries.add(item); continue; }
            } catch (_) {}
            final parts = value.split('|').map((e) => e.trim()).toList();
            if (parts.length >= 2) entries.add({'name': parts[0], 'endpoint': parts[1],
              'queryParam': parts.length > 2 ? parts[2] : 'q'});
          }
        }
        for (final entry in entries) {
          if (entry is! Map) continue;
          final map = Map<String, dynamic>.from(entry);
          final name = (map['name'] ?? map['bookSourceName'] ?? map['title'] ?? '').toString().trim();
          final endpoint = (map['endpoint'] ?? map['searchUrl'] ?? map['searchEndpoint'] ?? map['api'] ?? '').toString().trim();
          final endpointUri = Uri.tryParse(endpoint);
          if (name.isEmpty || endpointUri == null || !_isSafeSourceUri(endpointUri)) continue;
          final matching = bookSources.where((source) =>
            (source.subscriptionUrl == link && source.name == name) ||
            (source.subscriptionUrl == null && source.endpoint == endpointUri.toString())
          ).toList();
          if (matching.isNotEmpty) {
            final source = matching.first;
            source
              ..name = name
              ..endpoint = endpointUri.toString()
              ..queryParam = (map['queryParam'] ?? map['searchParam'] ?? 'q').toString()
              ..kind = map['kind'] == '正版授权书源' ? '正版授权书源' : '私人书源'
              ..subscriptionUrl = link;
            updated++;
          } else {
            bookSources.add(BookSource(
              name: name, endpoint: endpointUri.toString(),
              queryParam: (map['queryParam'] ?? map['searchParam'] ?? 'q').toString(),
              kind: map['kind'] == '正版授权书源' ? '正版授权书源' : '私人书源',
              enabled: map['enabled'] != false,
              subscriptionUrl: link,
            ));
            added++;
          }
        }
      } catch (_) { failed++; }
    }
    if (!mounted) return;
    setState(() {});
    await _saveSettings();
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('订阅更新完成：新增 $added 个、更新 $updated 个、失败 $failed 个')),
    );
  }

  Future<void> _importSourceFile() async {
    final result = await FilePicker.platform.pickFiles(
      type: FileType.custom, allowedExtensions: ['json', 'txt'], withData: true,
    );
    if (result == null || result.files.isEmpty) return;
    try {
      final file = result.files.first;
      final bytes = file.bytes ?? await File(file.path!).readAsBytes();
      final raw = utf8.decode(bytes, allowMalformed: true).trim();
      final candidates = <BookSource>[];
      var unsupported = 0;

      // Accept native JSON, common source-list wrappers, JSON-lines, and a simple
      // text interchange format: name|https://api.example/search|queryParam.
      dynamic decoded;
      try {
        decoded = jsonDecode(raw);
      } catch (_) {
        decoded = null;
      }

      final entries = <dynamic>[];
      if (decoded is List) {
        entries.addAll(decoded);
      } else if (decoded is Map) {
        final map = Map<String, dynamic>.from(decoded);
        final nested = map['sources'] ?? map['data'] ?? map['bookSources'];
        if (nested is List) {
          entries.addAll(nested);
        } else {
          entries.add(map);
        }
      } else {
        for (final line in raw.split(RegExp(r'\r?\n'))) {
          final trimmed = line.trim();
          if (trimmed.isEmpty || trimmed.startsWith('#')) continue;
          try {
            final item = jsonDecode(trimmed);
            if (item is Map) {
              entries.add(item);
              continue;
            }
          } catch (_) {}
          final parts = trimmed.split('|').map((e) => e.trim()).toList();
          if (parts.length >= 2) {
            entries.add({
              'name': parts[0],
              'endpoint': parts[1],
              'queryParam': parts.length >= 3 ? parts[2] : 'q',
            });
          } else {
            unsupported++;
          }
        }
      }

      for (final entry in entries) {
        if (entry is! Map) {
          unsupported++;
          continue;
        }
        final map = Map<String, dynamic>.from(entry);
        final name = (map['name'] ?? map['bookSourceName'] ?? map['title'] ?? '').toString().trim();
        // Only explicit API/search endpoint fields are mapped. A website base
        // URL plus arbitrary parsing scripts is not treated as a search API.
        final endpoint = (map['endpoint'] ?? map['searchUrl'] ??
          map['searchEndpoint'] ?? map['api'] ?? '').toString().trim();
        final queryParam = (map['queryParam'] ?? map['searchParam'] ?? 'q').toString().trim();
        final kind = (map['kind'] ?? '私人书源').toString();
        final uri = Uri.tryParse(endpoint);
        if (name.isEmpty || uri == null || !_isSafeSourceUri(uri)) {
          unsupported++;
          continue;
        }
        if (candidates.any((s) => s.endpoint == uri.toString()) ||
            bookSources.any((s) => s.endpoint == uri.toString())) {
          continue;
        }
        candidates.add(BookSource(
          name: name,
          endpoint: uri.toString(),
          queryParam: queryParam.isEmpty ? 'q' : queryParam,
          kind: kind == '正版授权书源' ? kind : '私人书源',
          enabled: map['enabled'] != false,
        ));
      }

      if (!mounted) return;
      if (candidates.isEmpty) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('没有找到可直接使用的搜索 API；跳过 $unsupported 条不兼容或不安全配置')),
        );
        return;
      }

      final confirmed = await showDialog<bool>(
        context: context,
        builder: (ctx) => AlertDialog(
          title: const Text('书源导入预览'),
          content: SizedBox(
            width: double.maxFinite,
            child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('识别到 ${candidates.length} 个可导入 API，另有 $unsupported 条配置暂不兼容。'),
              const SizedBox(height: 10),
              SizedBox(height: 260, child: ListView(
                shrinkWrap: true,
                children: candidates.take(8).map((source) => ListTile(
                  dense: true,
                  contentPadding: EdgeInsets.zero,
                  leading: const Icon(Icons.cloud_outlined),
                  title: Text(source.name, maxLines: 1, overflow: TextOverflow.ellipsis),
                  subtitle: Text(source.endpoint, maxLines: 2, overflow: TextOverflow.ellipsis),
                )).toList(),
              )),
              if (candidates.length > 8)
                Text('以及另外 ${candidates.length - 8} 个…', style: const TextStyle(color: muted)),
              const SizedBox(height: 8),
              const Text('仅导入明确声明的 HTTPS 搜索 API；不会执行配置中的脚本或网页抓取规则。',
                style: TextStyle(color: muted, fontSize: 11, height: 1.45)),
            ]),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('取消')),
            FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('确认导入')),
          ],
        ),
      );
      if (confirmed != true || !mounted) return;
      setState(() => bookSources.addAll(candidates));
      await _saveSettings();
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('导入完成：新增 ${candidates.length} 个书源；跳过 $unsupported 条不兼容配置')),
      );
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('书源文件无法解析：$e')),
      );
    }
  }

  Future<int?> _testBookSource(BookSource source) async {
    final uri = Uri.tryParse(source.endpoint);
    if (uri == null || !_isSafeSourceUri(uri)) return null;
    final watch = Stopwatch()..start();
    try {
      final response = await http.get(uri).timeout(const Duration(seconds: 8));
      watch.stop();
      if (response.statusCode >= 200 && response.statusCode < 500) {
        source.status = '连接正常';
        source.lastLatencyMs = watch.elapsedMilliseconds;
        return source.lastLatencyMs;
      }
      source.status = 'HTTP ${response.statusCode}';
      source.lastLatencyMs = null;
      return null;
    } catch (_) {
      source.status = '连接失败';
      source.lastLatencyMs = null;
      return null;
    }
  }

  Future<void> _testAllSources() async {
    if (bookSources.isEmpty) return;
    setState(() {
      sourceSearching = true;
      sourceSearchMessage = '正在检测书源连接…';
    });
    await Future.wait(bookSources.map(_testBookSource));
    bookSources.sort((a, b) => (a.lastLatencyMs ?? 1 << 30).compareTo(b.lastLatencyMs ?? 1 << 30));
    await _saveSettings();
    if (mounted) setState(() {
      sourceSearching = false;
      sourceSearchMessage = '连接检测完成，已按响应速度排序';
    });
  }

  Future<void> _searchBookSources(String keyword) async {
    if (keyword.trim().isEmpty) return;
    final enabled = bookSources.where((s) => s.enabled).toList();
    if (enabled.isEmpty) {
      setState(() {
        sourceResults = [];
        sourceSearchMessage = '请先添加并启用书源';
      });
      return;
    }
    setState(() {
      sourceSearching = true;
      sourceResults = [];
      sourceSearchMessage = '正在并发搜索 ${enabled.length} 个书源…';
    });
    final futures = enabled.map((source) async {
      final watch = Stopwatch()..start();
      try {
        final base = Uri.parse(source.endpoint);
        final params = Map<String, String>.from(base.queryParameters);
        params[source.queryParam] = keyword.trim();
        final uri = base.replace(queryParameters: params);
        final response = await http.get(uri, headers: {'Accept': 'application/json'})
          .timeout(const Duration(seconds: 12));
        watch.stop();
        if (response.statusCode < 200 || response.statusCode >= 300) {
          source.status = '搜索失败 HTTP ${response.statusCode}';
          return <SourceSearchResult>[];
        }
        final data = jsonDecode(utf8.decode(response.bodyBytes));
        final list = data is List ? data :
          (data is Map && data['results'] is List ? data['results'] as List :
          (data is Map && data['docs'] is List ? data['docs'] as List : const []));
        source.status = '搜索正常';
        source.lastLatencyMs = watch.elapsedMilliseconds;
        return list.whereType<Map>().map((item) {
          final m = Map<String, dynamic>.from(item);
          final title = (m['title'] ?? m['name'] ?? '').toString().trim();
          if (title.isEmpty) return null;
          final formats = m['formats'] is Map ? Map<String, dynamic>.from(m['formats']) : <String, dynamic>{};
          final formatUrl = formats['text/plain; charset=utf-8'] ??
            formats['text/plain'] ?? formats['text/plain; charset=us-ascii'] ??
            formats['application/epub+zip'] ?? formats['text/html'];
          final openLibraryKey = (m['key'] ?? '').toString();
          final openLibraryUrl = openLibraryKey.startsWith('/works/')
            ? 'https://openlibrary.org$openLibraryKey' : '';
          final resultUrl = (m['url'] ?? formatUrl ?? openLibraryUrl).toString();
          final parsedUrl = Uri.tryParse(resultUrl);
          final rawAuthors = m['authors'];
          final authorNames = m['author_name'];
          final author = rawAuthors is List
            ? rawAuthors.whereType<Map>().map((a) => (a['name'] ?? '').toString()).where((a) => a.isNotEmpty).join('、')
            : (authorNames is List ? authorNames.join('、') : (m['author'] ?? '').toString());
          final rawSubjects = m['subjects'];
          final description = (m['description'] ?? m['intro'] ??
            (rawSubjects is List ? rawSubjects.take(5).join('、') : '')).toString();
          return SourceSearchResult(
            title: title,
            author: author,
            description: description,
            url: parsedUrl != null && parsedUrl.scheme == 'https' ? resultUrl : '',
            sourceName: source.name,
            latencyMs: watch.elapsedMilliseconds,
          );
        }).whereType<SourceSearchResult>().toList();
      } catch (_) {
        source.status = '搜索超时或返回格式不正确';
        source.lastLatencyMs = null;
        return <SourceSearchResult>[];
      }
    }).toList();

    final batches = await Future.wait(futures);
    final all = batches.expand((e) => e).toList()
      ..sort((a, b) => a.latencyMs.compareTo(b.latencyMs));
    final seen = <String>{};
    final unique = all.where((r) => seen.add('${r.title.toLowerCase()}|${r.author.toLowerCase()}')).toList();
    await _saveSettings();
    if (mounted) setState(() {
      sourceResults = unique;
      sourceSearching = false;
      sourceSearchMessage = unique.isEmpty ? '没有找到结果，请检查书源接口协议和连接状态' : '找到 ${unique.length} 条结果，已按书源响应速度排序';
    });
  }

  void _showAddSourceDialog() {
    final name = TextEditingController();
    final endpoint = TextEditingController();
    final queryParam = TextEditingController(text: 'q');
    String kind = '私人书源';
    showDialog(context: context, builder: (dialogContext) => StatefulBuilder(
      builder: (dialogContext, setDialog) => AlertDialog(
        title: const Text('添加接口书源'),
        content: SingleChildScrollView(child: Column(mainAxisSize: MainAxisSize.min, children: [
          TextField(controller: name, decoration: const InputDecoration(labelText: '书源名称')),
          TextField(controller: endpoint, keyboardType: TextInputType.url,
            decoration: const InputDecoration(labelText: 'HTTPS 搜索接口地址', hintText: 'https://example.com/api/search')),
          TextField(controller: queryParam, decoration: const InputDecoration(labelText: '搜索参数名', helperText: '默认 q，例如 ?q=书名')),
          const SizedBox(height: 8),
          DropdownButtonFormField<String>(
            value: kind, decoration: const InputDecoration(labelText: '书源类型'),
            items: const [DropdownMenuItem(value: '正版授权书源', child: Text('正版授权书源')),
              DropdownMenuItem(value: '私人书源', child: Text('私人书源'))],
            onChanged: (v) => setDialog(() => kind = v ?? '私人书源'),
          ),
        ])),
        actions: [
          TextButton(onPressed: () => Navigator.pop(dialogContext), child: const Text('取消')),
          FilledButton(onPressed: () {
            Navigator.pop(dialogContext);
            _addSourceByUrl(name.text, endpoint.text, queryParam.text, kind);
          }, child: const Text('添加')),
        ],
      ),
    ));
  }

  void _applyAppLook(AppLook look) {
    setState(() => appLook = look);
    _saveSettings();
  }

  void _openAppAppearance() {
    showModalBottomSheet(
      context: context, isScrollControlled: true, useSafeArea: true,
      showDragHandle: true, backgroundColor: const Color(0xFF242229),
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(28))),
      builder: (_) => AppAppearanceStudio(
        selected: appLook,
        favorites: favoriteLookIds,
        onSelect: (look) {
          _applyAppLook(look);
        },
        onFavoritesChanged: (ids) {
          setState(() => favoriteLookIds = ids);
          _saveSettings();
        },
      ),
    );
  }

  void _openPaletteStudio() {
    showModalBottomSheet(
      context: context, isScrollControlled: true, useSafeArea: true,
      showDragHandle: true, backgroundColor: const Color(0xFF242229),
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(28))),
      builder: (_) => PaletteStudio(
        initial: readerPalette,
        onApply: (palette) {
          _applyPalette(palette);
          Navigator.pop(context);
        },
      ),
    );
  }

  Future<void> _importBook() async {
    final result = await FilePicker.platform.pickFiles(
      type: FileType.custom, allowedExtensions: ['txt', 'epub'],
      withData: true,
    );
    if (result == null || result.files.isEmpty) return;
    final f = result.files.first;
    try {
      final bytes = f.bytes ?? await File(f.path!).readAsBytes();
      String content;
      if (f.extension?.toLowerCase() == 'epub') {
        content = _epubText(bytes);
      } else {
        content = utf8.decode(bytes, allowMalformed: true);
      }
      if (content.trim().isEmpty) throw Exception('文件中没有可读取的正文');
      final book = Book(
        title: f.name.replaceAll(RegExp(r'\.(txt|epub)$', caseSensitive: false), ''),
        author: '本地文件',
        content: content,
      );
      setState(() => books.insert(0, book));
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('已导入《${book.title}》')),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('导入失败：$e')),
        );
      }
    }
  }

  String _epubText(List<int> bytes) {
    final archive = ZipDecoder().decodeBytes(bytes);
    final htmlFiles = archive.files.where((f) =>
      f.isFile && (f.name.toLowerCase().endsWith('.xhtml') ||
                   f.name.toLowerCase().endsWith('.html') ||
                   f.name.toLowerCase().endsWith('.htm'))).toList();
    htmlFiles.sort((a, b) => a.name.compareTo(b.name));
    final out = StringBuffer();
    for (final f in htmlFiles) {
      final raw = utf8.decode(f.content as List<int>, allowMalformed: true);
      final doc = html_parser.parse(raw);
      final text = doc.body?.text ?? doc.documentElement?.text ?? '';
      if (text.trim().isNotEmpty) out.writeln(text.trim());
    }
    return out.toString();
  }

  @override
  Widget build(BuildContext context) {
    final pages = [
      _home(),
      _shelf(),
      _discover(),
      _profile(),
      _sourceCenter(),
    ];
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        brightness: appLook.background.computeLuminance() > .45 ? Brightness.light : Brightness.dark,
        scaffoldBackgroundColor: appLook.background,
        colorScheme: ColorScheme(
          brightness: appLook.background.computeLuminance() > .45 ? Brightness.light : Brightness.dark,
          primary: appLook.accent, onPrimary: appLook.background,
          secondary: appLook.accent, onSecondary: appLook.background,
          error: const Color(0xFFCF6679), onError: Colors.black,
          surface: appLook.surface, onSurface: appLook.text,
        ),
        appBarTheme: AppBarTheme(backgroundColor: appLook.background, foregroundColor: appLook.text),
        useMaterial3: true,
      ),
      home: Scaffold(
        body: SafeArea(child: pages[tab]),
        extendBody: true,
        bottomNavigationBar: SafeArea(
          minimum: const EdgeInsets.fromLTRB(18, 0, 18, 8),
          child: ClipRRect(
            borderRadius: BorderRadius.circular(30),
            child: BackdropFilter(
              filter: ui.ImageFilter.blur(sigmaX: 24, sigmaY: 24),
              child: Container(
                height: 66,
                decoration: BoxDecoration(
                  color: appLook.nav,
                  borderRadius: BorderRadius.circular(30),
                  border: Border.all(color: Colors.white.withOpacity(.12)),
                  boxShadow: [BoxShadow(color: Colors.black.withOpacity(.24), blurRadius: 24, offset: const Offset(0, 8))],
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceAround,
                  children: [
                    _tabItem(Icons.home_rounded, '首页', 0),
                    _tabItem(Icons.auto_stories_rounded, '书架', 1),
                    _tabItem(Icons.explore_rounded, '发现', 2),
                    _tabItem(Icons.person_rounded, '我的', 3),
                    _tabItem(Icons.hub_outlined, '书源', 4),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _tabItem(IconData icon, String label, int index) {
    final selected = tab == index;
    return Expanded(
      child: InkWell(
        borderRadius: BorderRadius.circular(24),
        onTap: () => setState(() => tab = index),
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 220),
          curve: Curves.easeOutCubic,
          margin: const EdgeInsets.symmetric(horizontal: 5, vertical: 7),
          decoration: BoxDecoration(
            color: selected ? appLook.accent.withOpacity(.15) : Colors.transparent,
            borderRadius: BorderRadius.circular(22),
          ),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(icon, size: 21, color: selected ? appLook.accent : appLook.muted),
              const SizedBox(height: 3),
              Text(label, style: TextStyle(fontSize: 10, fontWeight: selected ? FontWeight.w600 : FontWeight.w400,
                color: selected ? appLook.accent : appLook.muted)),
            ],
          ),
        ),
      ),
    );
  }

  Widget _header(String subtitle) => Padding(
    padding: const EdgeInsets.fromLTRB(22, 20, 20, 16),
    child: Row(crossAxisAlignment: CrossAxisAlignment.end, children: [
      Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text('小书苑', style: TextStyle(fontSize: 31, fontWeight: FontWeight.w800, letterSpacing: -1.1, color: appLook.text)),
        const SizedBox(height: 4),
        Text(subtitle, style: const TextStyle(color: Color(0xFFAAA7B1), fontSize: 12)),
      ])),
      Material(
        color: appLook.surface,
        shape: const CircleBorder(),
        child: IconButton(
          tooltip: '搜索',
          onPressed: () => setState(() => tab = 2),
          icon: Icon(Icons.search_rounded, color: appLook.accent),
        ),
      ),
    ]),
  );

  Widget _home() => ListView(padding: EdgeInsets.zero, children: [
    _header('让阅读成为一种享受'),
    Padding(
      padding: const EdgeInsets.symmetric(horizontal: 18),
      child: Container(
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(20),
          gradient: LinearGradient(colors: [appLook.heroStart, appLook.heroEnd]),
        ),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text('今日精选', style: TextStyle(color: appLook.accent, fontSize: 13)),
          const SizedBox(height: 12),
          const Text('在文字里，遇见\\n另一个世界。', style: TextStyle(fontSize: 25, height: 1.35, fontWeight: FontWeight.bold)),
          const SizedBox(height: 14),
          OutlinedButton.icon(onPressed: _importBook, icon: const Icon(Icons.file_upload_outlined), label: const Text('导入 TXT / EPUB')),
        ]),
      ),
    ),
    _sectionTitle('继续阅读'),
    ...books.take(2).map((b) => _bookTile(b)),
    _sectionTitle('阅读分类'),
    Padding(
      padding: const EdgeInsets.symmetric(horizontal: 18),
      child: Wrap(spacing: 9, runSpacing: 9, children: ['玄幻', '都市', '仙侠', '言情', '悬疑', '历史'].map((s) =>
        Chip(label: Text(s), backgroundColor: panel, side: BorderSide.none)).toList()),
    ),
    const SizedBox(height: 20),
  ]);

  Widget _sectionTitle(String s) => Padding(
    padding: const EdgeInsets.fromLTRB(20, 24, 20, 10),
    child: Text(s, style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: appLook.text)),
  );

  Widget _bookTile(Book b) => ListTile(
    contentPadding: const EdgeInsets.symmetric(horizontal: 18, vertical: 5),
    leading: Container(width: 52, height: 68,
      decoration: BoxDecoration(color: b.coverColor, borderRadius: BorderRadius.circular(8)),
      child: Icon(Icons.auto_stories, color: appLook.accent, size: 26)),
    title: Text(b.title, style: const TextStyle(fontWeight: FontWeight.w600)),
    subtitle: Text('${b.author} · ${b.source}', style: TextStyle(color: muted, fontSize: 12)),
    trailing: const Icon(Icons.chevron_right, color: muted),
    onTap: () => _openBookDetail(b),
  );

  Widget _shelf() => Column(children: [
    _header('收藏与阅读记录'),
    Expanded(child: books.isEmpty
      ? const Center(child: Text('书架还是空的，去导入一本书吧', style: TextStyle(color: muted)))
      : ListView(children: books.map(_bookTile).toList())),
    Padding(padding: const EdgeInsets.all(16), child: FilledButton.icon(
      onPressed: _importBook, icon: const Icon(Icons.add), label: const Text('导入本地小说'),
    )),
  ]);

  Widget _discover() => ListView(children: [
    _header('发现好书'),
    Padding(padding: const EdgeInsets.symmetric(horizontal: 18), child: TextField(
      onChanged: (v) => setState(() => query = v),
      decoration: InputDecoration(
        hintText: '搜索书架中的书名',
        prefixIcon: const Icon(Icons.search),
        filled: true, fillColor: appLook.surface,
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: BorderSide.none),
      ),
    )),
    _sectionTitle('搜索结果'),
    ...books.where((b) => b.title.toLowerCase().contains(query.toLowerCase())).map(_bookTile),
    if (books.where((b) => b.title.toLowerCase().contains(query.toLowerCase())).isEmpty)
      const Padding(padding: EdgeInsets.all(24), child: Text('没有找到匹配的本地书籍', style: TextStyle(color: muted))),
    _sectionTitle('正版书库'),
    const Padding(padding: EdgeInsets.symmetric(horizontal: 20), child: Text(
      '正版书库将在接入出版社或内容平台授权接口后开放。当前版本不会抓取或展示未经授权的小说内容。',
      style: TextStyle(color: muted, height: 1.6))),
  ]);


  Widget _sourceCenter() => ListView(padding: const EdgeInsets.only(bottom: 110), children: [
    _header('管理正版与私人书库'),
    Padding(padding: const EdgeInsets.symmetric(horizontal: 18), child: TextField(
      onSubmitted: _searchBookSources,
      decoration: InputDecoration(
        hintText: '搜索已启用书源中的小说',
        prefixIcon: const Icon(Icons.search),
        filled: true, fillColor: appLook.surface,
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(16), borderSide: BorderSide.none),
      ),
    )),
    Padding(padding: const EdgeInsets.fromLTRB(18, 12, 18, 0), child: Row(children: [
      Expanded(child: OutlinedButton.icon(
        onPressed: _importSourceFile, icon: const Icon(Icons.file_upload_outlined), label: const Text('导入书源文件'),
      )),
      const SizedBox(width: 9),
      Expanded(child: FilledButton.icon(
        onPressed: _showAddSourceDialog, icon: const Icon(Icons.add_link), label: const Text('添加接口'),
      )),
    ])),
    Padding(padding: const EdgeInsets.fromLTRB(18, 10, 18, 0), child: Row(children: [
      Expanded(child: OutlinedButton.icon(
        onPressed: _subscribeSourceLink,
        icon: const Icon(Icons.rss_feed),
        label: const Text('链接订阅'),
      )),
      const SizedBox(width: 6),
      Expanded(child: OutlinedButton.icon(
        onPressed: _shareSourceConfig,
        icon: const Icon(Icons.qr_code),
        label: const Text('二维码分享'),
      )),
      const SizedBox(width: 6),
      Expanded(child: OutlinedButton.icon(
        onPressed: _refreshSourceSubscriptions,
        icon: const Icon(Icons.sync),
        label: const Text('更新订阅'),
      )), 
    ])),
    Padding(padding: const EdgeInsets.fromLTRB(18, 10, 18, 0), child: OutlinedButton.icon(
      onPressed: _addPublicDomainSource,
      icon: const Icon(Icons.public),
      label: const Text('一键添加题材书库（公版经典 + Open Library 言情/LGBTQ+书目）'),
    )),
    Padding(padding: const EdgeInsets.fromLTRB(18, 12, 18, 0), child: Row(children: [
      Expanded(child: Text('我的书源（${bookSources.length}）', style: TextStyle(fontSize: 17, fontWeight: FontWeight.bold, color: appLook.text))),
      TextButton.icon(onPressed: sourceSearching ? null : _testAllSources,
        icon: const Icon(Icons.speed, size: 17), label: const Text('测速排序')),
    ])),
    if (sourceSearchMessage.isNotEmpty)
      Padding(padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 5),
        child: Text(sourceSearchMessage, style: TextStyle(color: muted, fontSize: 12))),
    if (bookSources.isEmpty)
      Padding(padding: const EdgeInsets.all(20), child: Container(
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(color: appLook.surface, borderRadius: BorderRadius.circular(18)),
        child: Column(children: [
          Icon(Icons.library_add_outlined, size: 34, color: appLook.accent),
          const SizedBox(height: 8),
          Text('还没有添加书源', style: TextStyle(color: appLook.text, fontWeight: FontWeight.w600)),
          const SizedBox(height: 4),
          Text('支持 JSON / TXT 配置；自动识别常见字段并预览可导入 API。', textAlign: TextAlign.center,
            style: TextStyle(color: muted, fontSize: 12)),
        ]),
      )),
    ...bookSources.asMap().entries.map((entry) {
      final index = entry.key;
      final source = entry.value;
      return Card(
        margin: const EdgeInsets.symmetric(horizontal: 18, vertical: 5),
        color: appLook.surface, elevation: 0,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
        child: Padding(padding: const EdgeInsets.all(12), child: Row(children: [
          Container(width: 40, height: 40, decoration: BoxDecoration(color: appLook.accent.withOpacity(.13), borderRadius: BorderRadius.circular(12)),
            child: Icon(Icons.menu_book_outlined, color: appLook.accent)),
          const SizedBox(width: 10),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(source.name, style: TextStyle(color: appLook.text, fontWeight: FontWeight.w600)),
            const SizedBox(height: 3),
            Text('${source.kind} · ${source.status}${source.lastLatencyMs == null ? '' : ' · ${source.lastLatencyMs} ms'}',
              style: TextStyle(color: appLook.muted, fontSize: 11), maxLines: 1, overflow: TextOverflow.ellipsis),
          ])),
          Switch.adaptive(value: source.enabled, activeColor: appLook.accent, onChanged: (v) {
            setState(() => source.enabled = v);
            _saveSettings();
          }),
          PopupMenuButton<String>(
            onSelected: (action) async {
              if (action == 'test') {
                setState(() => source.status = '检测中');
                await _testBookSource(source);
                await _saveSettings();
                if (mounted) setState(() {});
              } else if (action == 'delete') {
                setState(() => bookSources.removeAt(index));
                _saveSettings();
              }
            },
            itemBuilder: (_) => const [
              PopupMenuItem(value: 'test', child: Text('测试连接')),
              PopupMenuItem(value: 'delete', child: Text('删除书源')),
            ],
          ),
        ])),
      );
    }),
    if (sourceResults.isNotEmpty) ...[
      Padding(padding: const EdgeInsets.fromLTRB(18, 20, 18, 8), child: Text('搜索结果（按响应速度排序）',
        style: TextStyle(fontSize: 17, fontWeight: FontWeight.bold, color: appLook.text))),
      ...sourceResults.map((r) => ListTile(
        leading: Icon(Icons.book_outlined, color: appLook.accent),
        title: Text(r.title, style: TextStyle(color: appLook.text)),
        subtitle: Text('${r.author.isEmpty ? '作者未知' : r.author} · ${r.sourceName} · ${r.latencyMs} ms',
          style: TextStyle(color: appLook.muted, fontSize: 11)),
        trailing: const Icon(Icons.chevron_right),
        onTap: () => _openOnlineBook(r),
      )),
    ],
    Padding(padding: const EdgeInsets.fromLTRB(20, 18, 20, 12), child: Text(
      '接口协议：GET 搜索，JSON 结果支持数组或 results 数组；支持标准 title/author/url，也兼容 Gutendex 的 authors、subjects、formats 字段。正文支持 JSON 或 HTTPS 纯文本下载地址。',
      style: TextStyle(color: appLook.muted, fontSize: 11, height: 1.5))),
  ]);

  void _openBookDetail(Book book) {
    Navigator.of(context).push(MaterialPageRoute(builder: (_) => BookDetailPage(
      book: book,
      onRead: () => _openReader(book),
    )));
  }

  void _openOnlineBook(SourceSearchResult result) {
    Navigator.of(context).push(MaterialPageRoute(builder: (_) => OnlineBookDetailPage(
      result: result,
      initialFont: fontSize,
      initialPalette: readerPalette,
      onOpenBook: (book) {
        setState(() {
          if (!books.any((b) => b.title == book.title && b.source == book.source)) {
            books.insert(0, book);
          }
        });
        _openReader(book);
      },
    )));
  }

  Widget _paletteDot(Color color) => Container(
    width: 23, height: 23,
    decoration: BoxDecoration(color: color, shape: BoxShape.circle,
      border: Border.all(color: Colors.white.withOpacity(.25))),
  );

  Widget _profile() => ListView(children: [
    _header('个人中心'),
    const SizedBox(height: 18),
    Center(child: CircleAvatar(radius: 34, backgroundColor: appLook.surface, child: Icon(Icons.person, color: appLook.accent, size: 34))),
    const SizedBox(height: 10),
    Center(child: Text('书苑读者', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: appLook.text))),
    _sectionTitle('整体界面'),
    ListTile(
      leading: Icon(Icons.dashboard_customize_outlined, color: appLook.accent),
      title: const Text('APP 外观风格'),
      subtitle: Text('${appLook.name} · 首页、导航栏、卡片与强调色'),
      trailing: const Icon(Icons.chevron_right),
      onTap: _openAppAppearance,
    ),
    _sectionTitle('阅读设置'),
    ListTile(
      leading: const Icon(Icons.palette_outlined, color: gold),
      title: const Text('阅读主题与调色盘'),
      subtitle: Text('${readerPalette.name} · 自由搭配纸张、文字与强调色'),
      trailing: const Icon(Icons.chevron_right),
      onTap: _openPaletteStudio,
    ),
    Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 4),
      child: Row(children: [
        _paletteDot(readerPalette.background),
        const SizedBox(width: 7),
        _paletteDot(readerPalette.text),
        const SizedBox(width: 7),
        _paletteDot(readerPalette.accent),
        const SizedBox(width: 10),
        Text('当前配色预览', style: TextStyle(color: muted, fontSize: 12)),
      ]),
    ),
    ListTile(
      title: const Text('默认字号'),
      subtitle: Slider(value: fontSize, min: 15, max: 28, divisions: 13,
        activeColor: gold, onChanged: (v) { setState(() => fontSize = v); _saveSettings(); }),
      trailing: Text('${fontSize.round()}'),
    ),
    const Divider(color: panel),
    const ListTile(leading: Icon(Icons.info_outline), title: Text('关于小书苑'), subtitle: Text('版本 1.7.2 · 多题材公版书库')),
  ]);

  void _openReader(Book book) {
    Navigator.of(context).push(MaterialPageRoute(builder: (_) => ReaderPage(
      book: book, initialFont: fontSize, initialPalette: readerPalette,
      onSettings: (s, palette) { setState(() { fontSize = s; readerPalette = palette; darkReader = palette.background.computeLuminance() < .12; }); _saveSettings(); },
    )));
  }
}



class BookDetailPage extends StatelessWidget {
  const BookDetailPage({super.key, required this.book, required this.onRead});
  final Book book;
  final VoidCallback onRead;
  @override
  Widget build(BuildContext context) {
    final chapters = splitBookChapters(book.content);
    return Scaffold(
      backgroundColor: const Color(0xFF101014),
      appBar: AppBar(title: const Text('小说详情'), backgroundColor: const Color(0xFF101014)),
      body: ListView(padding: const EdgeInsets.all(20), children: [
        Container(
          height: 170,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(20),
            gradient: const LinearGradient(colors: [Color(0xFF493725), Color(0xFF211D22)])),
          child: const Center(child: Icon(Icons.auto_stories_rounded, size: 58, color: gold)),
        ),
        const SizedBox(height: 20),
        Text(book.title, style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
        const SizedBox(height: 8),
        Text('${book.author} · ${book.source}', style: const TextStyle(color: muted)),
        const SizedBox(height: 20),
        const Text('作品简介', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
        const SizedBox(height: 8),
        Text(book.description.isEmpty ? '这本书尚未添加简介。' : book.description,
          style: const TextStyle(color: Color(0xFFCAC5C0), height: 1.7)),
        const SizedBox(height: 18),
        ListTile(
          contentPadding: EdgeInsets.zero,
          leading: const Icon(Icons.list_alt_rounded, color: gold),
          title: const Text('章节目录'),
          subtitle: Text('${chapters.length} 个章节/正文段落'),
        ),
        ...chapters.asMap().entries.take(5).map((entry) => ListTile(
          dense: true,
          leading: Text('${entry.key + 1}'.padLeft(2, '0'), style: const TextStyle(color: muted)),
          title: Text(entry.value.split('\\n').first.trim(), maxLines: 1, overflow: TextOverflow.ellipsis),
        )),
        if (chapters.length > 5)
          Padding(padding: const EdgeInsets.only(left: 16), child: Text('还有 ${chapters.length - 5} 个章节…',
            style: const TextStyle(color: muted, fontSize: 12))),
        const SizedBox(height: 18),
        FilledButton.icon(onPressed: onRead, icon: const Icon(Icons.menu_book_rounded), label: const Text('开始阅读')),
      ]),
    );
  }
}

class OnlineBookDetailPage extends StatefulWidget {
  const OnlineBookDetailPage({super.key, required this.result, required this.initialFont,
    required this.initialPalette, required this.onOpenBook});
  final SourceSearchResult result;
  final double initialFont;
  final ReaderPalette initialPalette;
  final ValueChanged<Book> onOpenBook;
  @override
  State<OnlineBookDetailPage> createState() => _OnlineBookDetailPageState();
}

class _OnlineBookDetailPageState extends State<OnlineBookDetailPage> {
  bool loading = false;
  String message = '选择“获取正版内容”后，将尝试读取书源提供的 HTTPS JSON 详情。';
  String content = '';
  String description = '';
  String author = '';
  Future<void> _loadOnlineContent() async {
    final uri = Uri.tryParse(widget.result.url);
    if (uri == null || uri.scheme != 'https' || uri.host.isEmpty) {
      setState(() => message = '该搜索结果没有提供可用的 HTTPS 详情地址。');
      return;
    }
    setState(() { loading = true; message = '正在读取书籍详情…'; });
    try {
      final response = await http.get(uri, headers: {'Accept': 'application/json'})
        .timeout(const Duration(seconds: 15));
      if (response.statusCode < 200 || response.statusCode >= 300) {
        throw Exception('服务返回 HTTP ${response.statusCode}');
      }
      final responseText = utf8.decode(response.bodyBytes, allowMalformed: true);
      final contentType = response.headers['content-type']?.toLowerCase() ?? '';
      dynamic data;
      try {
        data = jsonDecode(responseText);
      } catch (_) {
        data = null;
      }
      if (data is Map) {
        final map = Map<String, dynamic>.from(data);
        author = (map['author'] ?? widget.result.author).toString();
        description = (map['description'] ?? map['intro'] ?? widget.result.description).toString();
        final pieces = <String>[];
        final rawChapters = map['chapters'];
        if (rawChapters is List) {
          for (var i = 0; i < rawChapters.length; i++) {
            final item = rawChapters[i];
            if (item is Map) {
              final title = (item['title'] ?? '第 ${i + 1} 章').toString();
              final body = (item['content'] ?? item['text'] ?? '').toString();
              if (body.trim().isNotEmpty) pieces.add('$title\\n\\n$body');
            } else if (item is String && item.trim().isNotEmpty) {
              pieces.add(item.trim());
            }
          }
        }
        final body = (map['content'] ?? map['text'] ?? '').toString();
        content = pieces.isNotEmpty ? pieces.join('\\n\\n') : body;
      } else if (contentType.contains('text/plain') || !contentType.contains('application/json')) {
        content = responseText;
        author = widget.result.author;
        description = widget.result.description;
      } else {
        throw Exception('不支持的详情响应格式');
      }
      if (content.trim().isEmpty) {
        throw Exception('详情中没有正文。JSON 接口需提供 content 或 chapters；文本接口需返回纯文本正文。');
      }
      if (mounted) setState(() { loading = false; message = '内容已获取，可以加入书架并开始阅读。'; });
    } catch (e) {
      if (mounted) setState(() { loading = false; message = '暂时无法读取：$e'; });
    }
  }

  @override
  Widget build(BuildContext context) {
    final r = widget.result;
    return Scaffold(
      backgroundColor: const Color(0xFF101014),
      appBar: AppBar(title: const Text('小说详情'), backgroundColor: const Color(0xFF101014)),
      body: ListView(padding: const EdgeInsets.all(20), children: [
        Container(
          height: 170, decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(20),
            gradient: const LinearGradient(colors: [Color(0xFF493725), Color(0xFF211D22)])),
          child: const Center(child: Icon(Icons.auto_stories_rounded, size: 58, color: gold)),
        ),
        const SizedBox(height: 20),
        Text(r.title, style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
        const SizedBox(height: 8),
        Text('${r.author.isEmpty ? '作者未知' : r.author} · ${r.sourceName}',
          style: const TextStyle(color: muted)),
        const SizedBox(height: 18),
        const Text('作品简介', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
        const SizedBox(height: 8),
        Text(description.isEmpty ? (r.description.isEmpty ? '书源暂未提供作品简介。' : r.description) : description,
          style: const TextStyle(color: Color(0xFFCAC5C0), height: 1.7)),
        const SizedBox(height: 20),
        Text(message, style: const TextStyle(color: muted, height: 1.5)),
        const SizedBox(height: 14),
        FilledButton.icon(
          onPressed: loading ? null : _loadOnlineContent,
          icon: loading ? const SizedBox(width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2)) : const Icon(Icons.cloud_download_outlined),
          label: Text(loading ? '正在获取…' : '获取正版内容'),
        ),
        if (content.isNotEmpty) ...[
          const SizedBox(height: 10),
          OutlinedButton.icon(
            onPressed: () {
              final book = Book(title: r.title, author: author.isEmpty ? r.author : author,
                content: content, source: r.sourceName)..description = description;
              widget.onOpenBook(book);
            },
            icon: const Icon(Icons.menu_book_rounded),
            label: const Text('加入书架并开始阅读'),
          ),
          const SizedBox(height: 8),
          Text('已获取 ${splitBookChapters(content).length} 个章节/正文段落',
            style: const TextStyle(color: muted, fontSize: 12)),
        ],
        const SizedBox(height: 20),
        const Text('提示：仅使用你已获授权或有权访问的内容接口。详情接口需返回 JSON；支持 content/text，或 chapters 数组。', 
          style: TextStyle(color: muted, fontSize: 11, height: 1.5)),
      ]),
    );
  }
}

class ReaderPage extends StatefulWidget {
  const ReaderPage({super.key, required this.book, required this.initialFont,
    required this.initialPalette, required this.onSettings});
  final Book book;
  final double initialFont;
  final ReaderPalette initialPalette;
  final void Function(double, ReaderPalette) onSettings;
  @override
  State<ReaderPage> createState() => _ReaderPageState();
}

class _ReaderPageState extends State<ReaderPage> {
  late double size = widget.initialFont;
  late ReaderPalette palette = widget.initialPalette;
  bool controlsVisible = true;
  late final List<String> chapters = splitBookChapters(widget.book.content);
  final ScrollController _scrollController = ScrollController();
  @override
  void dispose() {
    _scrollController.dispose();
    super.dispose();
  }
  @override
  Widget build(BuildContext context) {
    final bgColor = palette.background;
    final fg = palette.text;
    return Scaffold(
      backgroundColor: bgColor,
      appBar: controlsVisible ? AppBar(
        elevation: 0,
        backgroundColor: bgColor,
        title: Text(widget.book.title, style: TextStyle(color: fg, fontSize: 16, fontWeight: FontWeight.w600)),
        iconTheme: IconThemeData(color: fg),
        actions: [IconButton(onPressed: _settings, icon: Icon(Icons.text_fields_rounded, color: fg))],
      ) : null,
      body: GestureDetector(
        behavior: HitTestBehavior.translucent,
        onTap: () => setState(() => controlsVisible = !controlsVisible),
        child: Stack(children: [
          ListView(
            controller: _scrollController,
            padding: EdgeInsets.fromLTRB(24, controlsVisible ? 18 : 52, 24, 90),
            children: [
              for (var i = 0; i < chapters.length; i++) ...[
                if (chapters.length > 1)
                  Padding(
                    padding: const EdgeInsets.only(top: 22, bottom: 12),
                    child: Text('第 ${i + 1} 节',
                      style: TextStyle(color: palette.accent, fontSize: 14, fontWeight: FontWeight.w700)),
                  ),
                Text(chapters[i], style: TextStyle(color: fg, fontSize: size, height: 1.95, letterSpacing: .35)),
              ],
            ],
          ),
          if (controlsVisible)
            Positioned(left: 18, right: 18, bottom: 18,
              child: ClipRRect(
                borderRadius: BorderRadius.circular(24),
                child: BackdropFilter(
                  filter: ui.ImageFilter.blur(sigmaX: 20, sigmaY: 20),
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 10),
                    decoration: BoxDecoration(color: palette.panel.withOpacity(.92),
                      borderRadius: BorderRadius.circular(24), border: Border.all(color: fg.withOpacity(.10))),
                    child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                      IconButton(onPressed: () => Navigator.pop(context), icon: Icon(Icons.chevron_left, color: fg)),
                      Text('阅读中 · ${widget.book.source}', style: TextStyle(color: fg.withOpacity(.8), fontSize: 11)),
                      IconButton(onPressed: _showChapterDirectory, icon: Icon(Icons.list_alt_rounded, color: fg)),
                      IconButton(onPressed: _settings, icon: Icon(Icons.tune_rounded, color: fg)),
                    ]),
                  ),
                ),
              )),
        ]),
      ),
    );
  }

  void _showChapterDirectory() {
    showModalBottomSheet(
      context: context, isScrollControlled: true, useSafeArea: true,
      backgroundColor: const Color(0xFF242229), showDragHandle: true,
      builder: (ctx) => SizedBox(
        height: MediaQuery.of(ctx).size.height * .68,
        child: Column(children: [
          const Padding(
            padding: EdgeInsets.all(16),
            child: Text('章节目录', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
          ),
          Expanded(child: ListView.builder(
            itemCount: chapters.length,
            itemBuilder: (_, i) => ListTile(
              leading: Icon(Icons.menu_book_outlined, color: palette.accent),
              title: Text(chapters.length == 1 ? '正文' : chapters[i].split('\\n').first.trim(),
                maxLines: 1, overflow: TextOverflow.ellipsis),
              subtitle: Text('第 ${i + 1} 节', style: const TextStyle(color: muted, fontSize: 11)),
              onTap: () {
                Navigator.pop(ctx);
                if (_scrollController.hasClients) {
                  final fraction = i / chapters.length;
                  _scrollController.animateTo(
                    _scrollController.position.maxScrollExtent * fraction,
                    duration: const Duration(milliseconds: 350), curve: Curves.easeOut,
                  );
                }
              },
            ),
          )),
        ]),
      ),
    );
  }

  void _settings() {
    showModalBottomSheet(
      context: context, isScrollControlled: true, useSafeArea: true,
      showDragHandle: true, backgroundColor: const Color(0xFF242229),
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(28))),
      builder: (ctx) => StatefulBuilder(builder: (ctx, setSheet) => Padding(
        padding: const EdgeInsets.all(22),
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          const Text('阅读设置', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
          const SizedBox(height: 12),
          Row(children: [
            const Text('字号'),
            Expanded(child: Slider(value: size, min: 15, max: 28, divisions: 13,
              activeColor: palette.accent, onChanged: (v) { setState(() => size = v); setSheet(() {}); })),
            Text('${size.round()}'),
          ]),
          ListTile(
            contentPadding: EdgeInsets.zero,
            leading: const Icon(Icons.palette_outlined),
            title: const Text('主题与调色盘'),
            subtitle: Text(palette.name),
            trailing: const Icon(Icons.chevron_right),
            onTap: () {
              Navigator.pop(ctx);
              showModalBottomSheet(
                context: context, isScrollControlled: true, useSafeArea: true,
                showDragHandle: true, backgroundColor: const Color(0xFF242229),
                shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(28))),
                builder: (_) => PaletteStudio(initial: palette, onApply: (p) {
                  setState(() => palette = p);
                  widget.onSettings(size, p);
                  Navigator.pop(context);
                }),
              );
            },
          ),
          FilledButton(
            style: FilledButton.styleFrom(backgroundColor: palette.accent, foregroundColor: palette.background),
            onPressed: () { widget.onSettings(size, palette); Navigator.pop(ctx); },
            child: const Text('完成'),
          ),
        ]),
      )),
    );
  }
}

/// Preset palettes plus an RGB mixing desk. Each channel can be tuned independently,
/// and the live sample previews the complete background / text / accent combination.
class PaletteStudio extends StatefulWidget {
  const PaletteStudio({super.key, required this.initial, required this.onApply});
  final ReaderPalette initial;
  final ValueChanged<ReaderPalette> onApply;
  @override
  State<PaletteStudio> createState() => _PaletteStudioState();
}

class _PaletteStudioState extends State<PaletteStudio> {
  late ReaderPalette palette = widget.initial;
  String target = '纸张';
  Color get targetColor => target == '纸张' ? palette.background : target == '文字' ? palette.text : palette.accent;
  void _setTargetColor(Color color) {
    setState(() {
      palette = target == '纸张'
        ? palette.copyWith(name: '我的搭配', background: color, panel: Color.lerp(color, palette.text, .08)!)
        : target == '文字'
          ? palette.copyWith(name: '我的搭配', text: color)
          : palette.copyWith(name: '我的搭配', accent: color);
    });
  }
  int _r(Color c) => (c.r * 255).round();
  int _g(Color c) => (c.g * 255).round();
  int _b(Color c) => (c.b * 255).round();
  @override
  Widget build(BuildContext context) {
    final sampleText = palette.text;
    return Padding(
      padding: EdgeInsets.fromLTRB(20, 8, 20, 20 + MediaQuery.of(context).viewInsets.bottom),
      child: SingleChildScrollView(child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisSize: MainAxisSize.min,
        children: [
          const Text('阅读主题工作室', style: TextStyle(fontSize: 21, fontWeight: FontWeight.bold)),
          const SizedBox(height: 5),
          const Text('选择完整配色，或用调色盘创造自己的阅读氛围', style: TextStyle(color: muted, fontSize: 12)),
          const SizedBox(height: 16),
          ClipRRect(
            borderRadius: BorderRadius.circular(18),
            child: Container(
              width: double.infinity, padding: const EdgeInsets.all(18),
              decoration: BoxDecoration(color: palette.background, border: Border.all(color: Colors.white.withOpacity(.12))),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Row(children: [
                  Text('小书苑 · 阅读预览', style: TextStyle(color: palette.accent, fontWeight: FontWeight.w700)),
                  const Spacer(),
                  Icon(Icons.auto_stories, color: palette.accent),
                ]),
                const SizedBox(height: 12),
                Text('第一章  山海长夜', style: TextStyle(color: sampleText, fontSize: 19, fontWeight: FontWeight.bold)),
                const SizedBox(height: 8),
                Text('山风穿过古老的松林，远处的群山隐没在薄雾之中。让每一段文字，都拥有适合自己的色彩。', style: TextStyle(color: sampleText, height: 1.8)),
                const SizedBox(height: 12),
                Container(height: 4, width: 75, decoration: BoxDecoration(color: palette.accent, borderRadius: BorderRadius.circular(9))),
              ]),
            ),
          ),
          const SizedBox(height: 18),
          const Text('完整搭色方案', style: TextStyle(fontSize: 15, fontWeight: FontWeight.w700)),
          const SizedBox(height: 10),
          SizedBox(height: 112, child: ListView.separated(
            scrollDirection: Axis.horizontal,
            itemCount: ReaderPalette.presets.length,
            separatorBuilder: (_, __) => const SizedBox(width: 10),
            itemBuilder: (context, index) {
              final item = ReaderPalette.presets[index];
              final selected = palette.name == item.name && palette.background == item.background && palette.text == item.text;
              return GestureDetector(
                onTap: () => setState(() => palette = item),
                child: Container(
                  width: 104, padding: const EdgeInsets.all(9),
                  decoration: BoxDecoration(color: const Color(0xFF34323A), borderRadius: BorderRadius.circular(14),
                    border: Border.all(color: selected ? gold : Colors.white12, width: selected ? 2 : 1)),
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Expanded(child: Row(children: [
                      Expanded(child: Container(decoration: BoxDecoration(color: item.background, borderRadius: BorderRadius.circular(7)))),
                      const SizedBox(width: 4),
                      Expanded(child: Container(decoration: BoxDecoration(color: item.text, borderRadius: BorderRadius.circular(7)))),
                      const SizedBox(width: 4),
                      Expanded(child: Container(decoration: BoxDecoration(color: item.accent, borderRadius: BorderRadius.circular(7)))),
                    ])),
                    const SizedBox(height: 7),
                    Text(item.name, style: const TextStyle(fontSize: 11), maxLines: 1, overflow: TextOverflow.ellipsis),
                  ]),
                ),
              );
            },
          )),
          const SizedBox(height: 18),
          const Text('自定义调色盘', style: TextStyle(fontSize: 15, fontWeight: FontWeight.w700)),
          const SizedBox(height: 9),
          Wrap(spacing: 8, children: ['纸张', '文字', '强调色'].map((name) => ChoiceChip(
            label: Text(name), selected: target == name,
            onSelected: (_) => setState(() => target = name),
          )).toList()),
          const SizedBox(height: 8),
          Row(children: [
            Container(width: 38, height: 38, decoration: BoxDecoration(color: targetColor, shape: BoxShape.circle, border: Border.all(color: Colors.white24))),
            const SizedBox(width: 10),
            Expanded(child: Text('$target · #${targetColor.value.toRadixString(16).substring(2).toUpperCase()}', style: TextStyle(color: muted, fontSize: 12))),
          ]),
          _rgbSlider('R', _r(targetColor), (v) => _setTargetColor(targetColor.withRed(v))),
          _rgbSlider('G', _g(targetColor), (v) => _setTargetColor(targetColor.withGreen(v))),
          _rgbSlider('B', _b(targetColor), (v) => _setTargetColor(targetColor.withBlue(v))),
          const SizedBox(height: 12),
          Row(children: [
            Expanded(child: OutlinedButton(
              onPressed: () => setState(() => palette = ReaderPalette.presets.first),
              child: const Text('恢复默认'),
            )),
            const SizedBox(width: 10),
            Expanded(child: FilledButton(
              style: FilledButton.styleFrom(backgroundColor: palette.accent, foregroundColor: palette.background),
              onPressed: () => widget.onApply(palette),
              child: const Text('应用这套配色'),
            )),
          ]),
        ],
      )),
    );
  }

  Widget _rgbSlider(String label, int value, ValueChanged<int> onChanged) => Row(children: [
    SizedBox(width: 18, child: Text(label, style: TextStyle(color: muted, fontSize: 12))),
    Expanded(child: Slider(value: value.toDouble(), min: 0, max: 255, divisions: 255,
      activeColor: targetColor, onChanged: (v) => onChanged(v.round()))),
    SizedBox(width: 30, child: Text('$value', textAlign: TextAlign.end, style: const TextStyle(color: muted, fontSize: 11))),
  ]);
}


class AppAppearanceStudio extends StatefulWidget {
  const AppAppearanceStudio({super.key, required this.selected, required this.favorites,
    required this.onSelect, required this.onFavoritesChanged});
  final AppLook selected;
  final List<int> favorites;
  final ValueChanged<AppLook> onSelect;
  final ValueChanged<List<int>> onFavoritesChanged;
  @override
  State<AppAppearanceStudio> createState() => _AppAppearanceStudioState();
}

class _AppAppearanceStudioState extends State<AppAppearanceStudio> {
  late int selectedIndex = AppLook.presets.indexOf(widget.selected).clamp(0, AppLook.presets.length - 1);
  late List<int> favorites = List<int>.from(widget.favorites);
  @override
  Widget build(BuildContext context) {
    final look = AppLook.presets[selectedIndex];
    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 8, 20, 24),
      child: SingleChildScrollView(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const Text('整体界面风格', style: TextStyle(fontSize: 21, fontWeight: FontWeight.bold)),
        const SizedBox(height: 5),
        const Text('更换整个小书苑的视觉氛围，不影响独立的阅读纸张主题。', style: TextStyle(color: muted, fontSize: 12)),
        const SizedBox(height: 16),
        Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: look.background, borderRadius: BorderRadius.circular(20),
            border: Border.all(color: Colors.white.withOpacity(.12)),
          ),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Row(children: [
              Text('小书苑', style: TextStyle(color: look.text, fontWeight: FontWeight.w800, fontSize: 22)),
              const Spacer(),
              Icon(Icons.search, color: look.accent),
            ]),
            const SizedBox(height: 12),
            Container(
              width: double.infinity, padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(15),
                gradient: LinearGradient(colors: [look.heroStart, look.heroEnd]),
              ),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text('今日精选', style: TextStyle(color: look.accent, fontSize: 11)),
                const SizedBox(height: 7),
                Text('在文字里，遇见\\n另一个世界。', style: TextStyle(color: look.text, fontWeight: FontWeight.bold, fontSize: 19)),
              ]),
            ),
            const SizedBox(height: 12),
            Row(children: [
              Expanded(child: Container(height: 30, decoration: BoxDecoration(color: look.surface, borderRadius: BorderRadius.circular(10)))),
              const SizedBox(width: 8),
              Expanded(child: Container(height: 30, decoration: BoxDecoration(color: look.surface, borderRadius: BorderRadius.circular(10)))),
              const SizedBox(width: 8),
              Expanded(child: Container(height: 30, decoration: BoxDecoration(color: look.surface, borderRadius: BorderRadius.circular(10)))),
            ]),
            const SizedBox(height: 12),
            Container(
              padding: const EdgeInsets.symmetric(vertical: 9),
              decoration: BoxDecoration(color: look.nav, borderRadius: BorderRadius.circular(20)),
              child: Row(mainAxisAlignment: MainAxisAlignment.spaceEvenly, children: [
                Icon(Icons.home, color: look.accent, size: 18),
                Icon(Icons.auto_stories, color: look.muted, size: 18),
                Icon(Icons.explore, color: look.muted, size: 18),
                Icon(Icons.person, color: look.muted, size: 18),
              ]),
            ),
          ]),
        ),
        const SizedBox(height: 18),
        const Text('选择整套外观', style: TextStyle(fontSize: 15, fontWeight: FontWeight.w700)),
        const SizedBox(height: 10),
        GridView.builder(
          shrinkWrap: true, physics: const NeverScrollableScrollPhysics(),
          itemCount: AppLook.presets.length,
          gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: 2, childAspectRatio: 2.25, crossAxisSpacing: 10, mainAxisSpacing: 10),
          itemBuilder: (context, index) {
            final item = AppLook.presets[index];
            final isSelected = selectedIndex == index;
            final isFavorite = favorites.contains(index);
            return GestureDetector(
              onTap: () => setState(() => selectedIndex = index),
              child: Container(
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(
                  color: const Color(0xFF34323A),
                  borderRadius: BorderRadius.circular(14),
                  border: Border.all(color: isSelected ? gold : Colors.white12, width: isSelected ? 2 : 1),
                ),
                child: Row(children: [
                  Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                    for (final c in [item.background, item.surface, item.accent])
                      Container(width: 13, height: 13, margin: const EdgeInsets.symmetric(vertical: 1),
                        decoration: BoxDecoration(color: c, shape: BoxShape.circle, border: Border.all(color: Colors.white24))),
                  ]),
                  const SizedBox(width: 8),
                  Expanded(child: Text(item.name, style: const TextStyle(fontSize: 12), maxLines: 1, overflow: TextOverflow.ellipsis)),
                  Icon(isSelected ? Icons.check_circle : Icons.circle_outlined, size: 17, color: isSelected ? gold : muted),
                  IconButton(
                    visualDensity: VisualDensity.compact, padding: EdgeInsets.zero,
                    onPressed: () => setState(() {
                      if (isFavorite) { favorites.remove(index); } else { favorites.add(index); }
                      widget.onFavoritesChanged(favorites);
                    }),
                    icon: Icon(isFavorite ? Icons.star : Icons.star_border, size: 17, color: isFavorite ? gold : muted),
                  ),
                ]),
              ),
            );
          },
        ),
        const SizedBox(height: 14),
        if (favorites.isNotEmpty) ...[
          const Text('我的风格收藏', style: TextStyle(fontSize: 15, fontWeight: FontWeight.w700)),
          const SizedBox(height: 8),
          Wrap(spacing: 7, runSpacing: 7, children: favorites.map((i) => Chip(
            avatar: const Icon(Icons.star, size: 14, color: gold),
            label: Text(AppLook.presets[i].name),
            backgroundColor: const Color(0xFF34323A),
          )).toList()),
          const SizedBox(height: 8),
        ],
        Row(children: [
          Expanded(child: OutlinedButton(
            onPressed: () => setState(() => selectedIndex = 0),
            child: const Text('恢复默认'),
          )),
          const SizedBox(width: 10),
          Expanded(child: FilledButton(
            style: FilledButton.styleFrom(backgroundColor: look.accent, foregroundColor: look.background),
            onPressed: () {
              widget.onSelect(look);
              Navigator.pop(context);
            },
            child: const Text('应用整体风格'),
          )),
        ]),
      ])),
    );
  }
}
