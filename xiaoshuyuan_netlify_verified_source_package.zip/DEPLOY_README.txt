小书苑 Netlify 部署包

此包包含 3 个需要放进 GitHub 仓库根目录的文件：
1. xiaoshuyuan_flutter_web_source.zip  原版小书苑 Flutter 源码（已做 Flutter Web 兼容调整）
2. netlify-build.sh                   Netlify 自动解压、安装 Flutter、构建网页的脚本
3. netlify.toml                       Netlify 构建与发布配置

操作：
A. 在 GitHub 仓库根目录上传以上三个文件并提交。
B. 打开 Netlify，Add new project -> Import an existing project -> GitHub。
C. 选择小书苑仓库。Build command 和 Publish directory 会从 netlify.toml 自动读取：
   Build command: bash netlify-build.sh
   Publish directory: site
D. 点击 Deploy。

注意：Netlify 首次构建需要联网下载 Flutter SDK 和 Dart 依赖，构建时间可能较长。
本包保留原 Flutter 页面与业务代码；Web 环境下本地文件通过浏览器文件选择器读取。
书源请求受浏览器 CORS 限制，个别第三方 API 可能无法直接访问。
