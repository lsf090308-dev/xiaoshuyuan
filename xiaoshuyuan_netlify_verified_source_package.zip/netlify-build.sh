#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
WORK="$ROOT/.netlify-build"
PROJECT="$WORK/xiaoshuyuan_flutter"

rm -rf "$WORK" "$ROOT/site"
mkdir -p "$WORK"
unzip -q "$ROOT/xiaoshuyuan_flutter_web_source.zip" -d "$WORK"

if ! command -v flutter >/dev/null 2>&1; then
  FLUTTER_DIR="${HOME}/flutter"
  if [ ! -x "$FLUTTER_DIR/bin/flutter" ]; then
    git clone --depth 1 --branch stable https://github.com/flutter/flutter.git "$FLUTTER_DIR"
  fi
  export PATH="$FLUTTER_DIR/bin:$PATH"
fi

cd "$PROJECT"
flutter config --enable-web
flutter create --platforms=web --project-name xiaoshuyuan .
flutter pub get
flutter build web --release --pwa-strategy=none --base-href /
mkdir -p "$ROOT/site"
cp -a build/web/. "$ROOT/site/"
